# Smelly Cat

Balança inteligente de estoque de areia de gatos integrada com EUGENIO.

## Hardware

* NodeMCU ESP8266
* 4 células de carga
* Sensor HX711

## Software

* Platformio
* [EUGENIO](https://eugenio.io/)

[Video Tutorial](https://youtu.be/dmI_Kcd-qe0)

`TODO: adicionar mais documentação`
